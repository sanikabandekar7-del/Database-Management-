
const express = require("express");
const mysql = require("mysql2/promise");

const app = express();
const PORT = 3000;

// Middleware to read JSON request bodies
app.use(express.json());

// MySQL connection pool
const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "mysql30",
  database: "student_db",
  waitForConnections: true,
  connectionLimit: 10
});

// Helper to validate student IDs
function isValidId(id) {
  return Number.isInteger(Number(id)) && Number(id) > 0;
}

// 1. GET: Retrieve all students
app.get("/api/students", async (req, res) => {
  try {
    const [students] = await pool.query(
      "SELECT * FROM students ORDER BY id"
    );

    res.status(200).json({
      success: true,
      data: students
    });
  } catch (error) {
    console.error("Error retrieving students:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve students"
    });
  }
});

// 2. GET: Retrieve one student by ID
app.get("/api/students/:id", async (req, res) => {
  if (!isValidId(req.params.id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid student ID"
    });
  }

  try {
    const [students] = await pool.execute(
      "SELECT * FROM students WHERE id = ?",
      [Number(req.params.id)]
    );

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    res.status(200).json({
      success: true,
      data: students[0]
    });
  } catch (error) {
    console.error("Error retrieving student:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve student"
    });
  }
});

// 3. POST: Add a new student
app.post("/api/students", async (req, res) => {
  const { name, course } = req.body;

  if (
    typeof name !== "string" ||
    !name.trim() ||
    name.trim().length > 100 ||
    typeof course !== "string" ||
    !course.trim() ||
    course.trim().length > 100
  ) {
    return res.status(400).json({
      success: false,
      message: "Valid name and course are required (maximum 100 characters each)"
    });
  }

  try {
    const [result] = await pool.execute(
      "INSERT INTO students (name, course) VALUES (?, ?)",
      [name.trim(), course.trim()]
    );

    const [students] = await pool.execute(
      "SELECT * FROM students WHERE id = ?",
      [result.insertId]
    );

    res.status(201).json({
      success: true,
      message: "Student added successfully",
      data: students[0]
    });
  } catch (error) {
    console.error("Error adding student:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to add student"
    });
  }
});

// 4. PUT: Update a student
app.put("/api/students/:id", async (req, res) => {
  if (!isValidId(req.params.id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid student ID"
    });
  }

  const { name, course } = req.body;

  if (
    typeof name !== "string" ||
    !name.trim() ||
    name.trim().length > 100 ||
    typeof course !== "string" ||
    !course.trim() ||
    course.trim().length > 100
  ) {
    return res.status(400).json({
      success: false,
      message: "Valid name and course are required (maximum 100 characters each)"
    });
  }

  try {
    const [result] = await pool.execute(
      "UPDATE students SET name = ?, course = ? WHERE id = ?",
      [name.trim(), course.trim(), Number(req.params.id)]
    );

    if (result.affectedRows === 0) {
      const [students] = await pool.execute(
        "SELECT id FROM students WHERE id = ?",
        [Number(req.params.id)]
      );

      if (students.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Student not found"
        });
      }
    }

    const [students] = await pool.execute(
      "SELECT * FROM students WHERE id = ?",
      [Number(req.params.id)]
    );

    res.status(200).json({
      success: true,
      message: "Student updated successfully",
      data: students[0]
    });
  } catch (error) {
    console.error("Error updating student:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to update student"
    });
  }
});

// 5. DELETE: Remove a student
app.delete("/api/students/:id", async (req, res) => {
  if (!isValidId(req.params.id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid student ID"
    });
  }

  try {
    const [students] = await pool.execute(
      "SELECT * FROM students WHERE id = ?",
      [Number(req.params.id)]
    );

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    await pool.execute(
      "DELETE FROM students WHERE id = ?",
      [Number(req.params.id)]
    );

    res.status(200).json({
      success: true,
      message: "Student deleted successfully",
      data: students[0]
    });
  } catch (error) {
    console.error("Error deleting student:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to delete student"
    });
  }
});

// Verify the database connection before starting the server
async function startServer() {
  try {
    const connection = await pool.getConnection();
    console.log("MySQL database connected successfully!");
    connection.release();

    app.listen(PORT, () => {
      console.log(`Server running at http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("MySQL connection failed:", error.message);
    console.error("Check that MySQL is running and your credentials are correct.");
    process.exit(1);
  }
}

startServer();
